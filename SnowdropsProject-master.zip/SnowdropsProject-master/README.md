Snowdrops OOP Project by Cillian, Ellen, Denis, Dan, Chinonso

Java application that connects to the College Database using JDBC. The command line is used to create, read, update and delete information from the database. There are 5 tables - Student, Course, Address, Lecturer, Modules. 
There are also three connecting tables that allow us to join multiple tables together using SQL commands. There are 5 classes, one for each table and also a databaseutils class to make it easier to connect to the database.
We have testing for the getters/setters of the 5 classes and an interface between the two super classes student and lecturer.
The DBcreate file shows how the SQL database was made.

Error with account Sign ins:

DenisJ123 = CiaraC03

Ellen signed in with two accounts: ellenmcintyre and ellenmcintyre123

Chinonso Account is the G00403720

Link to the video: https://youtu.be/4epB4n-v7rE

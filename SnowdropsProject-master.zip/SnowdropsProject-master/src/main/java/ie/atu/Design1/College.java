package ie.atu.Design1;

public interface College {
    String getFirst_name();

    String getLast_name();

    String getEmail();

}
